This example is built from three GitHub projects:

- Pjer-zhang/fortran-examples

- SonarSource/sonarqube
- mlliarm/fortran